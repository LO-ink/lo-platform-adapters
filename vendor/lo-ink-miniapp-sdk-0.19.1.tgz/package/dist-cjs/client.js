"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMiniAppClient = createMiniAppClient;
exports.supports = supports;
exports.subscribe = subscribe;
const errors_js_1 = require("./errors.js");
const request_options_js_1 = require("./request-options.js");
const MAX_TIMEOUT_MS = 2_147_483_647;
const operationCapability = {
    ready: "ready",
    close: "close",
    expand: "expand",
    requestFullscreen: "fullscreen",
    exitFullscreen: "fullscreen",
    hideKeyboard: "hideKeyboard",
    setOrientationLock: "orientation",
    setButton: "mainButton",
    setClosingConfirmation: "closingConfirmation",
    setHeaderColor: "headerColor",
    setBackgroundColor: "backgroundColor",
    setBottomBarColor: "bottomBarColor",
    haptic: "haptics",
    showPopup: "popup",
    openLink: "openLink",
    sendData: "sendData",
    switchInlineQuery: "switchInlineQuery",
    readClipboard: "clipboard",
    getLocation: "location",
    openLocationSettings: "location",
    getBiometryInfo: "biometry",
    requestBiometryAccess: "biometry",
    authenticateBiometry: "biometry",
    updateBiometryToken: "biometry",
    openBiometrySettings: "biometry",
    startAccelerometer: "sensors",
    stopAccelerometer: "sensors",
    startGyroscope: "sensors",
    stopGyroscope: "sensors",
    startDeviceOrientation: "sensors",
    stopDeviceOrientation: "sensors",
    downloadFile: "downloadFile",
    openQrScanner: "qrScanner",
    closeQrScanner: "qrScanner",
    requestWriteAccess: "requestWriteAccess",
    requestContact: "requestContact",
    shareMessage: "shareMessage",
    shareToStory: "shareToStory",
    openInvoice: "invoice",
    cloudStorageSet: "cloudStorage",
    cloudStorageGet: "cloudStorage",
    cloudStorageGetMany: "cloudStorage",
    cloudStorageRemove: "cloudStorage",
    cloudStorageRemoveMany: "cloudStorage",
    cloudStorageKeys: "cloudStorage",
    deviceStorageSet: "deviceStorage",
    deviceStorageGet: "deviceStorage",
    deviceStorageRemove: "deviceStorage",
    deviceStorageClear: "deviceStorage",
    secureStorageSet: "secureStorage",
    secureStorageGet: "secureStorage",
    secureStorageRestore: "secureStorage",
    secureStorageRemove: "secureStorage",
    secureStorageClear: "secureStorage",
};
const defaultTimeout = {
    requestWriteAccess: 60_000,
    requestContact: 60_000,
    shareMessage: 300_000,
    openInvoice: 300_000,
    secureStorageSet: 60_000,
    secureStorageGet: 60_000,
    secureStorageRestore: 60_000,
    secureStorageRemove: 60_000,
    secureStorageClear: 60_000,
};
function createMiniAppClient(adapter) {
    let disposed = false;
    const subscriptions = new Set();
    const pending = new Set();
    const client = {
        adapter,
        get disposed() {
            return disposed;
        },
        supports(capability) {
            return !disposed && adapter.capabilities.has(capability);
        },
        on(event, listener) {
            if (disposed)
                return () => { };
            let active = true;
            const releaseAdapter = adapter.subscribe(event, listener);
            const release = () => {
                if (!active)
                    return;
                active = false;
                subscriptions.delete(release);
                releaseAdapter();
            };
            subscriptions.add(release);
            if (disposed) {
                try {
                    release();
                }
                catch {
                    /* Disposal remains best effort. */
                }
            }
            return release;
        },
        async call(operation, input, options = {}) {
            if (disposed)
                throw new errors_js_1.MiniAppError("disposed");
            options = (0, request_options_js_1.readRequestOptions)(options);
            const capability = operation === "setButton"
                ? `${input.button}Button`
                : operationCapability[operation];
            if (capability && !adapter.capabilities.has(capability)) {
                throw new errors_js_1.MiniAppError("unsupported", `${operation} is not supported`);
            }
            const timeoutMs = options.timeoutMs ?? defaultTimeout[operation] ?? 30_000;
            if (!Number.isInteger(timeoutMs) ||
                timeoutMs < 1 ||
                timeoutMs > MAX_TIMEOUT_MS) {
                throw new RangeError(`timeoutMs must be an integer from 1 to ${MAX_TIMEOUT_MS}`);
            }
            if (options.signal?.aborted)
                throw new errors_js_1.MiniAppError("aborted");
            return new Promise((resolve, reject) => {
                let settled = false;
                let cleanupAdapter;
                let cleanupRan = false;
                let timer;
                const controller = new AbortController();
                const runCleanup = () => {
                    if (cleanupRan || !cleanupAdapter)
                        return;
                    cleanupRan = true;
                    try {
                        cleanupAdapter();
                    }
                    catch {
                        /* Cleanup must not change the result. */
                    }
                };
                const finish = (outcome) => {
                    if (settled)
                        return;
                    settled = true;
                    if (timer !== undefined)
                        clearTimeout(timer);
                    try {
                        options.signal?.removeEventListener("abort", abort);
                    }
                    catch {
                        /* Preserve request settlement. */
                    }
                    pending.delete(disposeRequest);
                    runCleanup();
                    if (outcome.ok)
                        resolve(outcome.value);
                    else
                        reject((0, errors_js_1.normalizeMiniAppError)(outcome.error));
                };
                const cancel = (reason) => {
                    if (!controller.signal.aborted)
                        controller.abort(reason);
                    finish({ ok: false, error: reason });
                };
                const abort = () => cancel(new errors_js_1.MiniAppError("aborted"));
                const disposeRequest = (reason) => cancel(reason);
                pending.add(disposeRequest);
                try {
                    options.signal?.addEventListener("abort", abort, { once: true });
                    if (settled)
                        return;
                    if (options.signal?.aborted) {
                        abort();
                        return;
                    }
                }
                catch (error) {
                    finish({ ok: false, error });
                    return;
                }
                timer = setTimeout(() => cancel(new errors_js_1.MiniAppError("timeout")), timeoutMs);
                try {
                    const request = adapter.execute(operation, input, {
                        signal: controller.signal,
                    });
                    const promise = "promise" in request ? request.promise : request;
                    cleanupAdapter = "promise" in request ? request.cleanup : undefined;
                    if (settled)
                        runCleanup();
                    Promise.resolve(promise).then((value) => finish({ ok: true, value }), (error) => finish({ ok: false, error }));
                }
                catch (error) {
                    finish({ ok: false, error });
                }
            });
        },
        dispose() {
            if (disposed)
                return;
            disposed = true;
            for (const release of [...subscriptions]) {
                try {
                    release();
                }
                catch {
                    /* Continue releasing remaining listeners. */
                }
            }
            const reason = new errors_js_1.MiniAppError("disposed");
            for (const cancel of [...pending]) {
                try {
                    cancel(reason);
                }
                catch {
                    /* Continue cancelling remaining calls. */
                }
            }
        },
    };
    return client;
}
function supports(target, capability) {
    if (!target)
        return false;
    return "adapter" in target
        ? target.supports(capability)
        : target.capabilities.has(capability);
}
function subscribe(client, event, listener) {
    return client?.on(event, listener) ?? (() => { });
}
