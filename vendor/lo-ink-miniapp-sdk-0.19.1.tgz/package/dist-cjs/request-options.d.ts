export type RequestOptions = {
    signal?: AbortSignal;
    timeoutMs?: number;
};
/** Snapshot caller-owned options before a request acquires timers or listeners. */
export declare function readRequestOptions(options: RequestOptions): RequestOptions;
