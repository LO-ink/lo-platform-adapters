import type { MiniAppAdapter } from "./adapter.js";
import type { Capability, MiniAppEvent, MiniAppEventMap, MiniAppOperation, OperationInput, OperationOutput } from "./protocol.js";
export type CallOptions = {
    signal?: AbortSignal;
    timeoutMs?: number;
};
export interface MiniAppClient {
    readonly adapter: MiniAppAdapter;
    readonly disposed: boolean;
    supports(capability: Capability): boolean;
    on<K extends MiniAppEvent>(event: K, listener: (payload: MiniAppEventMap[K]) => void): () => void;
    call<K extends MiniAppOperation>(operation: K, input: OperationInput<K>, options?: CallOptions): Promise<OperationOutput<K>>;
    dispose(): void;
}
export declare function createMiniAppClient(adapter: MiniAppAdapter): MiniAppClient;
export declare function supports(target: MiniAppClient | MiniAppAdapter | null, capability: Capability): boolean;
export declare function subscribe<K extends MiniAppEvent>(client: MiniAppClient | null, event: K, listener: (payload: MiniAppEventMap[K]) => void): () => void;
