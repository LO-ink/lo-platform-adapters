import type { MiniAppClient } from "./client.js";
type AppearanceEnvironment = {
    root: {
        dataset: Record<string, string | undefined>;
        style: {
            setProperty(name: string, value: string): void;
        };
    };
    prefersDark(): boolean;
    background(variable: string): string;
    onPreferenceChange(listener: () => void): () => void;
};
/** Binds normalized host appearance without reading a platform global. */
export declare function bindAppearance(client: MiniAppClient | null, environment: AppearanceEnvironment, options?: {
    backgroundVariable?: string;
}): () => void;
export {};
