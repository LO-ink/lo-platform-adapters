/** Adapts a callback API and ignores late callbacks after timeout or abort. */
export declare function withHostCallback<T>(start: (finish: (error: unknown, value?: T) => void) => void | (() => void), options?: {
    signal?: AbortSignal;
    timeoutMs?: number;
}): Promise<T>;
