import type { MiniAppClient, CallOptions } from "./client.js";
export declare function cloudStorage(client: MiniAppClient): {
    setItem: (key: string, value: string, options?: CallOptions) => Promise<boolean>;
    getItem: (key: string, options?: CallOptions) => Promise<string>;
    getItems: (keys: readonly string[], options?: CallOptions) => Promise<Record<string, string>>;
    removeItem: (key: string, options?: CallOptions) => Promise<boolean>;
    removeItems: (keys: readonly string[], options?: CallOptions) => Promise<boolean>;
    getKeys: (options?: CallOptions) => Promise<string[]>;
};
export declare function deviceStorage(client: MiniAppClient): {
    setItem: (key: string, value: string, options?: CallOptions) => Promise<boolean>;
    getItem: (key: string, options?: CallOptions) => Promise<string | null>;
    removeItem: (key: string, options?: CallOptions) => Promise<boolean>;
    clear: (options?: CallOptions) => Promise<boolean>;
};
export declare function secureStorage(client: MiniAppClient): {
    setItem: (key: string, value: string, options?: CallOptions) => Promise<boolean>;
    getItem: (key: string, options?: CallOptions) => Promise<{
        value: string | null;
        canRestore: boolean;
    }>;
    restoreItem: (key: string, options?: CallOptions) => Promise<string>;
    removeItem: (key: string, options?: CallOptions) => Promise<boolean>;
    clear: (options?: CallOptions) => Promise<boolean>;
};
