import type { MiniAppAdapter } from "./adapter.js";
export interface AppSession {
    token: string;
    startParam: string;
}
/** Cache entries are hints. The server must validate launch data and cached sessions. */
export declare function authenticate<T extends AppSession>(adapter: MiniAppAdapter, options: {
    storageKey: string;
    authenticate: (launch: {
        adapterId: string;
        launchData: string;
    }) => Promise<T>;
    validate: (token: string) => Promise<unknown>;
    isUnauthorized: (error: unknown) => boolean;
    storage?: Storage | null;
}): Promise<AppSession>;
