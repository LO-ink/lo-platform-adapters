"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cloudStorage = cloudStorage;
exports.deviceStorage = deviceStorage;
exports.secureStorage = secureStorage;
function cloudStorage(client) {
    return {
        setItem: (key, value, options) => client.call("cloudStorageSet", { key, value }, options),
        getItem: (key, options) => client.call("cloudStorageGet", { key }, options),
        getItems: (keys, options) => client.call("cloudStorageGetMany", { keys }, options),
        removeItem: (key, options) => client.call("cloudStorageRemove", { key }, options),
        removeItems: (keys, options) => client.call("cloudStorageRemoveMany", { keys }, options),
        getKeys: (options) => client.call("cloudStorageKeys", undefined, options),
    };
}
function deviceStorage(client) {
    return {
        setItem: (key, value, options) => client.call("deviceStorageSet", { key, value }, options),
        getItem: (key, options) => client.call("deviceStorageGet", { key }, options),
        removeItem: (key, options) => client.call("deviceStorageRemove", { key }, options),
        clear: (options) => client.call("deviceStorageClear", undefined, options),
    };
}
function secureStorage(client) {
    return {
        setItem: (key, value, options) => client.call("secureStorageSet", { key, value }, options),
        getItem: (key, options) => client.call("secureStorageGet", { key }, options),
        restoreItem: (key, options) => client.call("secureStorageRestore", { key }, options),
        removeItem: (key, options) => client.call("secureStorageRemove", { key }, options),
        clear: (options) => client.call("secureStorageClear", undefined, options),
    };
}
