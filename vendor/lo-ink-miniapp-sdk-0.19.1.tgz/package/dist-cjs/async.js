"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withHostCallback = withHostCallback;
const errors_js_1 = require("./errors.js");
const request_options_js_1 = require("./request-options.js");
const MAX_TIMEOUT_MS = 2_147_483_647;
/** Adapts a callback API and ignores late callbacks after timeout or abort. */
async function withHostCallback(start, options = {}) {
    options = (0, request_options_js_1.readRequestOptions)(options);
    const timeoutMs = options.timeoutMs ?? 30_000;
    if (!Number.isInteger(timeoutMs) ||
        timeoutMs < 1 ||
        timeoutMs > MAX_TIMEOUT_MS) {
        return Promise.reject(new RangeError(`timeoutMs must be an integer from 1 to ${MAX_TIMEOUT_MS}`));
    }
    return new Promise((resolve, reject) => {
        let settled = false;
        let cleanup;
        let cleanupRan = false;
        let timer;
        const runCleanup = () => {
            if (cleanupRan || !cleanup)
                return;
            cleanupRan = true;
            try {
                cleanup();
            }
            catch {
                /* Cleanup must not replace the request result. */
            }
        };
        const settleSuccess = (value) => {
            if (settled)
                return;
            settled = true;
            if (timer !== undefined)
                clearTimeout(timer);
            try {
                options.signal?.removeEventListener("abort", abort);
            }
            catch {
                /* Preserve request settlement. */
            }
            runCleanup();
            resolve(value);
        };
        const settleFailure = (error) => {
            if (settled)
                return;
            settled = true;
            if (timer !== undefined)
                clearTimeout(timer);
            try {
                options.signal?.removeEventListener("abort", abort);
            }
            catch {
                /* Preserve request settlement. */
            }
            runCleanup();
            reject((0, errors_js_1.normalizeMiniAppError)(error));
        };
        const finish = (error, value) => {
            if (error == null)
                settleSuccess(value);
            else
                settleFailure(error);
        };
        const abort = () => settleFailure(new errors_js_1.MiniAppError("aborted"));
        try {
            options.signal?.addEventListener("abort", abort, { once: true });
            if (settled)
                return;
            if (options.signal?.aborted)
                return abort();
        }
        catch (error) {
            settleFailure(error);
            return;
        }
        timer = setTimeout(() => settleFailure(new errors_js_1.MiniAppError("timeout")), timeoutMs);
        try {
            cleanup = start(finish);
            if (settled)
                runCleanup();
        }
        catch (error) {
            settleFailure(error);
        }
    });
}
