"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestContact = exports.requestWriteAccess = void 0;
exports.shareMessage = shareMessage;
exports.shareToStory = shareToStory;
const requestWriteAccess = (client, options) => client.call("requestWriteAccess", undefined, {
    timeoutMs: 60_000,
    ...options,
});
exports.requestWriteAccess = requestWriteAccess;
const requestContact = (client, options) => client.call("requestContact", undefined, { timeoutMs: 60_000, ...options });
exports.requestContact = requestContact;
function shareMessage(client, id, options) {
    if (typeof id !== "string" || !id.length || id.length > 128) {
        return Promise.reject(new TypeError("Invalid prepared message ID"));
    }
    return client.call("shareMessage", { id }, { timeoutMs: 300_000, ...options });
}
function validateStoryUrl(value, media) {
    if (typeof value !== "string" ||
        value.length > 8192 ||
        !/^https?:\/\//i.test(value) ||
        /[\s\\\u0000-\u001f\u007f]/.test(value)) {
        throw new TypeError("Invalid story URL");
    }
    const url = new URL(value);
    if (!url.hostname ||
        url.username ||
        url.password ||
        (media && url.protocol !== "https:")) {
        throw new TypeError("Invalid story URL");
    }
}
async function shareToStory(client, mediaUrl, params, options) {
    validateStoryUrl(mediaUrl, true);
    if (params?.text !== undefined &&
        (typeof params.text !== "string" || params.text.length > 2048)) {
        throw new TypeError("Invalid story caption");
    }
    if (params?.link) {
        validateStoryUrl(params.link.url, false);
        if (params.link.name !== undefined &&
            (typeof params.link.name !== "string" || params.link.name.length > 48)) {
            throw new TypeError("Invalid story link label");
        }
    }
    return client.call("shareToStory", { mediaUrl, params }, options);
}
