import type { CallOptions, MiniAppClient } from "./client.js";
import type { StoryShareParams } from "./protocol.js";
export declare const requestWriteAccess: (client: MiniAppClient, options?: CallOptions) => Promise<boolean>;
export declare const requestContact: (client: MiniAppClient, options?: CallOptions) => Promise<boolean>;
export declare function shareMessage(client: MiniAppClient, id: string, options?: CallOptions): Promise<boolean>;
export declare function shareToStory(client: MiniAppClient, mediaUrl: string, params?: StoryShareParams, options?: CallOptions): Promise<void>;
