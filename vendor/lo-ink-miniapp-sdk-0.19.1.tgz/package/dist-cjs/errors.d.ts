export type MiniAppErrorCode = "unsupported" | "timeout" | "aborted" | "disposed" | "failed" | "invalid-response";
export declare class MiniAppError extends Error {
    readonly code: MiniAppErrorCode;
    constructor(code: MiniAppErrorCode, message?: string, options?: ErrorOptions);
}
export declare function normalizeMiniAppError(error: unknown): MiniAppError;
