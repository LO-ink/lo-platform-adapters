"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MINI_APP_LIMITS = exports.MINI_APP_PROTOCOL_VERSION = exports.MINI_APP_CAPABILITIES = void 0;
/** Stable, platform-neutral features a host can advertise. */
exports.MINI_APP_CAPABILITIES = [
    "ready",
    "expand",
    "fullscreen",
    "hideKeyboard",
    "orientation",
    "backButton",
    "mainButton",
    "secondaryButton",
    "settingsButton",
    "closingConfirmation",
    "headerColor",
    "backgroundColor",
    "bottomBarColor",
    "haptics",
    "popup",
    "openLink",
    "sendData",
    "switchInlineQuery",
    "clipboard",
    "location",
    "biometry",
    "sensors",
    "downloadFile",
    "qrScanner",
    "requestWriteAccess",
    "requestContact",
    "shareMessage",
    "shareToStory",
    "invoice",
    "cloudStorage",
    "deviceStorage",
    "secureStorage",
];
exports.MINI_APP_PROTOCOL_VERSION = 1;
exports.MINI_APP_LIMITS = Object.freeze({
    envelopeBytes: 65_536,
    sendDataBytes: 4_096,
    inlineQueryLength: 256,
    qrPromptLength: 64,
    preparedMessageIdLength: 128,
});
