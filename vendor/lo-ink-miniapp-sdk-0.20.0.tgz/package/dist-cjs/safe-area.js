"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bindSafeAreaCss = bindSafeAreaCss;
const errors_js_1 = require("./errors.js");
/** Sum host cutout and header insets; missing data preserves CSS env() fallbacks. */
function bindSafeAreaCss(client, options = {}) {
    const prefix = options.prefix ?? "--lo-safe";
    if (!/^--[a-zA-Z0-9_-]+$/.test(prefix))
        throw new TypeError("Expected a CSS custom-property prefix");
    if (typeof document === "undefined" || client.disposed)
        return () => { };
    const style = document.documentElement.style;
    const previous = new Map();
    const written = new Map();
    let safeArea;
    let contentSafeArea;
    let active = true;
    const write = () => {
        if (!active || (!safeArea && !contentSafeArea))
            return;
        for (const edge of ["top", "right", "bottom", "left"]) {
            const safe = safeArea?.[edge] ?? 0;
            const content = contentSafeArea?.[edge] ?? 0;
            if (!Number.isFinite(safe) ||
                safe < 0 ||
                !Number.isFinite(content) ||
                content < 0)
                continue;
            const name = `${prefix}-${edge}`;
            if (!previous.has(name))
                previous.set(name, {
                    value: style.getPropertyValue(name),
                    priority: style.getPropertyPriority(name),
                });
            const value = `${safe + content}px`;
            style.setProperty(name, value);
            written.set(name, value);
        }
    };
    const snapshot = (value) => {
        if (value.safeArea !== undefined)
            safeArea = value.safeArea;
        if (value.contentSafeArea !== undefined)
            contentSafeArea = value.contentSafeArea;
        write();
    };
    snapshot(client.adapter.snapshot());
    const releases = [];
    const subscribe = (event, listener) => {
        try {
            releases.push(client.on(event, listener));
        }
        catch (error) {
            if (!(error instanceof errors_js_1.MiniAppError) || error.code !== "unsupported")
                throw error;
        }
    };
    try {
        subscribe("safeAreaChanged", (value) => {
            safeArea = value;
            write();
        });
        subscribe("contentSafeAreaChanged", (value) => {
            contentSafeArea = value;
            write();
        });
        subscribe("viewportChanged", (value) => snapshot(value));
    }
    catch (error) {
        for (const release of releases)
            release();
        for (const [name, old] of previous) {
            if (old.value)
                style.setProperty(name, old.value, old.priority);
            else
                style.removeProperty(name);
        }
        throw error;
    }
    return () => {
        if (!active)
            return;
        active = false;
        for (const release of releases)
            release();
        for (const [name, old] of previous) {
            if (style.getPropertyValue(name) !== written.get(name))
                continue;
            if (old.value)
                style.setProperty(name, old.value, old.priority);
            else
                style.removeProperty(name);
        }
    };
}
