import { type LaunchData } from "./launch.js";
export type InitDataErrorCode = "invalid-data" | "invalid-signature" | "wrong-app-id" | "expired" | "future-auth-date" | "duplicate-parameter";
export declare class InitDataError extends Error {
    readonly code: InitDataErrorCode;
    constructor(code: InitDataErrorCode);
}
export interface VerifyInitDataOptions {
    /** LO Connect app key, exactly as supplied; never base64-decode it. */
    appKey: string;
    appId: string;
    maxAgeSec: number;
    /** Clock override for deterministic tests. Defaults to current Unix seconds. */
    nowSec?: number;
}
export interface VerifiedInitData extends LaunchData {
    readonly authDate: number;
    readonly appId: string;
}
/** Verify registered-app data on the server. Import only from /server. */
export declare function verifyInitData(raw: string, options: VerifyInitDataOptions): VerifiedInitData;
