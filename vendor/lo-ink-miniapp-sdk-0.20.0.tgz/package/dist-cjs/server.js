"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InitDataError = void 0;
exports.verifyInitData = verifyInitData;
const node_crypto_1 = require("node:crypto");
const launch_js_1 = require("./launch.js");
class InitDataError extends Error {
    code;
    constructor(code) {
        super(code);
        this.code = code;
        this.name = "InitDataError";
    }
}
exports.InitDataError = InitDataError;
/** Verify registered-app data on the server. Import only from /server. */
function verifyInitData(raw, options) {
    if (!options ||
        typeof options.appKey !== "string" ||
        !options.appKey ||
        typeof options.appId !== "string" ||
        !options.appId ||
        !Number.isSafeInteger(options.maxAgeSec) ||
        options.maxAgeSec < 0)
        throw new TypeError("Expected appKey, appId and a non-negative integer maxAgeSec");
    const now = options.nowSec ?? Math.floor(Date.now() / 1000);
    if (!Number.isSafeInteger(now) || now < 0)
        throw new TypeError("Invalid clock");
    let params;
    try {
        params = (0, launch_js_1.decodeLaunchParams)(raw);
    }
    catch (error) {
        throw new InitDataError(error instanceof launch_js_1.DuplicateLaunchParameter
            ? "duplicate-parameter"
            : "invalid-data");
    }
    const hash = params.get("hash");
    if (!hash || !/^[a-fA-F0-9]{64}$/.test(hash))
        throw new InitDataError("invalid-signature");
    const joined = [...params]
        .filter(([key]) => key !== "hash" && key !== "signature")
        .sort(([a], [b]) => {
        const x = new TextEncoder().encode(a);
        const y = new TextEncoder().encode(b);
        for (let i = 0; i < Math.min(x.length, y.length); i++) {
            if (x[i] !== y[i])
                return x[i] - y[i];
        }
        return x.length - y.length;
    })
        .map(([key, value]) => `${key}=${value}`)
        .join("\n");
    const secret = (0, node_crypto_1.createHmac)("sha256", "WebAppData")
        .update(options.appKey)
        .digest();
    const expected = (0, node_crypto_1.createHmac)("sha256", secret).update(joined).digest();
    const actual = Uint8Array.from(hash.match(/../g), (part) => parseInt(part, 16));
    if (!(0, node_crypto_1.timingSafeEqual)(expected, actual))
        throw new InitDataError("invalid-signature");
    if (params.get("app_id") !== options.appId)
        throw new InitDataError("wrong-app-id");
    const date = params.get("auth_date");
    if (!date || !/^[0-9]+$/.test(date) || !Number.isSafeInteger(Number(date)))
        throw new InitDataError("invalid-data");
    const authDate = Number(date);
    if (authDate > now + 300)
        throw new InitDataError("future-auth-date");
    if (now - authDate > options.maxAgeSec)
        throw new InitDataError("expired");
    try {
        return { ...(0, launch_js_1.launchDataFromParams)(params), authDate, appId: options.appId };
    }
    catch {
        throw new InitDataError("invalid-data");
    }
}
