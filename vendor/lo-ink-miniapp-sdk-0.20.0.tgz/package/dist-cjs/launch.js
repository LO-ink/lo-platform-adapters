"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuplicateLaunchParameter = void 0;
exports.decodeLaunchParams = decodeLaunchParams;
exports.launchDataFromParams = launchDataFromParams;
exports.parseLaunchDataUnsafe = parseLaunchDataUnsafe;
/** Strict query decoding shared by the display parser and server verifier. */
function decodeLaunchParams(raw) {
    if (typeof raw !== "string" || new TextEncoder().encode(raw).length > 65536)
        throw new TypeError("Invalid launch data");
    const params = new Map();
    if (!raw)
        return params;
    for (const pair of raw.split("&")) {
        if (!pair)
            continue;
        const equals = pair.indexOf("=");
        const decode = (s) => decodeURIComponent(s.replace(/\+/g, " "));
        const name = decode(equals < 0 ? pair : pair.slice(0, equals));
        const value = decode(equals < 0 ? "" : pair.slice(equals + 1));
        if (!name)
            throw new TypeError("Invalid launch parameter");
        if (params.has(name))
            throw new DuplicateLaunchParameter(name);
        params.set(name, value);
    }
    return params;
}
class DuplicateLaunchParameter extends Error {
    parameter;
    constructor(parameter) {
        super("Duplicate launch parameter");
        this.parameter = parameter;
    }
}
exports.DuplicateLaunchParameter = DuplicateLaunchParameter;
function launchUser(raw) {
    if (raw === undefined)
        return undefined;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
        throw new TypeError("Invalid launch user");
    const user = parsed;
    // JSON.parse loses integer precision on older browsers. Read the top-level id
    // token from the original JSON, after validating the entire document above.
    const tokens = raw.match(/"(?:\\[\s\S]|[^"\\])*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|[{}\[\]:,]|true|false|null/g) ?? [];
    let depth = 0;
    let id;
    let found = false;
    for (let i = 0; i < tokens.length; i++) {
        const token = tokens[i];
        if (token === "{" || token === "[")
            depth++;
        else if (token === "}" || token === "]")
            depth--;
        else if (depth === 1 &&
            token.startsWith('"') &&
            tokens[i + 1] === ":" &&
            JSON.parse(token) === "id") {
            if (found)
                throw new TypeError("Duplicate user identifier");
            found = true;
            const value = tokens[i + 2];
            id = value?.startsWith('"') ? JSON.parse(value) : value;
        }
    }
    if (typeof id !== "string" || !/^[1-9][0-9]*$/.test(id))
        throw new TypeError("Invalid launch user identifier");
    let photoUrl;
    if (typeof user.photo_url === "string") {
        try {
            const url = new URL(user.photo_url);
            if (user.photo_url.trim() === user.photo_url &&
                url.protocol === "https:" &&
                url.hostname.endsWith(".lo.ink") &&
                !url.username &&
                !url.password &&
                !url.port &&
                !/[\u0000\r\n\t]/.test(user.photo_url))
                photoUrl = user.photo_url;
        }
        catch {
            /* An untrusted avatar is omitted. */
        }
    }
    const optional = (key) => typeof user[key] === "string" ? user[key] : undefined;
    return {
        id,
        firstName: optional("first_name"),
        lastName: optional("last_name"),
        username: optional("username"),
        photoUrl,
        languageCode: optional("language_code"),
    };
}
function launchDataFromParams(params) {
    const date = params.get("auth_date");
    const authDate = date !== undefined &&
        /^[0-9]+$/.test(date) &&
        Number.isSafeInteger(Number(date))
        ? Number(date)
        : undefined;
    return {
        user: launchUser(params.get("user")),
        authDate,
        appId: params.get("app_id"),
        startParam: params.get("start_param"),
        chatType: params.get("chat_type"),
        queryId: params.get("query_id"),
    };
}
/** Unverified host data for rendering; never an authentication credential. */
function parseLaunchDataUnsafe(raw) {
    try {
        return launchDataFromParams(decodeLaunchParams(raw));
    }
    catch {
        return {};
    }
}
