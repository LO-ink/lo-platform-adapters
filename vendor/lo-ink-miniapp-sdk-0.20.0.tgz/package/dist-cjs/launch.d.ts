/** Display-only identity. Trust it only after server signature verification. */
export interface LaunchUser {
    readonly id: string;
    readonly firstName?: string;
    readonly lastName?: string;
    readonly username?: string;
    readonly photoUrl?: string;
    readonly languageCode?: string;
}
export interface LaunchData {
    readonly user?: LaunchUser;
    readonly startParam?: string;
    readonly chatType?: string;
    readonly authDate?: number;
    readonly appId?: string;
    readonly queryId?: string;
}
/** Strict query decoding shared by the display parser and server verifier. */
export declare function decodeLaunchParams(raw: string): Map<string, string>;
export declare class DuplicateLaunchParameter extends Error {
    readonly parameter: string;
    constructor(parameter: string);
}
export declare function launchDataFromParams(params: ReadonlyMap<string, string>): LaunchData;
/** Unverified host data for rendering; never an authentication credential. */
export declare function parseLaunchDataUnsafe(raw: string): LaunchData;
