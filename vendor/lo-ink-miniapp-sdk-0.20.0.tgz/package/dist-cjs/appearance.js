"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bindAppearance = bindAppearance;
/** Binds normalized host appearance without reading a platform global. */
function bindAppearance(client, environment, options = {}) {
    if (!client)
        return () => { };
    const update = () => {
        const snapshot = client.adapter.snapshot();
        const preference = environment.root.dataset.preference;
        const dark = preference === "dark" ||
            (preference !== "light" &&
                (snapshot.colorScheme === "dark" ||
                    (!snapshot.colorScheme && environment.prefersDark())));
        environment.root.dataset.theme = dark ? "dark" : "light";
        environment.root.style.setProperty("--host-top", `${Math.max(snapshot.safeArea?.top ?? 0, snapshot.contentSafeArea?.top ?? 0)}px`);
        environment.root.style.setProperty("--host-bottom", `${Math.max(snapshot.safeArea?.bottom ?? 0, snapshot.contentSafeArea?.bottom ?? 0)}px`);
        const background = environment
            .background(options.backgroundVariable ?? "--page-background")
            .trim();
        if (/^#[0-9a-f]{6}$/i.test(background)) {
            if (client.supports("headerColor"))
                void client
                    .call("setHeaderColor", { color: background })
                    .catch(() => { });
            if (client.supports("backgroundColor"))
                void client
                    .call("setBackgroundColor", { color: background })
                    .catch(() => { });
        }
    };
    update();
    const releases = [];
    try {
        releases.push(environment.onPreferenceChange(update));
        for (const event of [
            "themeChanged",
            "viewportChanged",
            "safeAreaChanged",
            "contentSafeAreaChanged",
        ]) {
            try {
                releases.push(client.on(event, update));
            }
            catch (error) {
                // Appearance is optional. Keep the initial snapshot, system preference
                // and every event the host actually provides; propagate real failures.
                if (!error ||
                    typeof error !== "object" ||
                    !("code" in error) ||
                    error.code !== "unsupported")
                    throw error;
            }
        }
    }
    catch (error) {
        for (const release of releases) {
            try {
                release();
            }
            catch {
                /* Continue releasing previously bound listeners. */
            }
        }
        throw error;
    }
    return () => {
        for (const release of releases) {
            try {
                release();
            }
            catch {
                /* Continue releasing remaining listeners. */
            }
        }
    };
}
