"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NoBot = exports.MiniAppError = void 0;
exports.normalizeMiniAppError = normalizeMiniAppError;
class MiniAppError extends Error {
    code;
    constructor(code, message = code, options) {
        super(message, options);
        this.code = code;
        this.name = "MiniAppError";
    }
}
exports.MiniAppError = MiniAppError;
function normalizeMiniAppError(error) {
    if (error instanceof MiniAppError)
        return error;
    if (error instanceof Error) {
        return new MiniAppError("failed", error.message || "Host request failed", {
            cause: error,
        });
    }
    return new MiniAppError("failed", "Host request failed", { cause: error });
}
class NoBot extends MiniAppError {
    constructor() {
        super("no-bot", "No bot is linked to this mini app");
        this.name = "NoBot";
    }
}
exports.NoBot = NoBot;
