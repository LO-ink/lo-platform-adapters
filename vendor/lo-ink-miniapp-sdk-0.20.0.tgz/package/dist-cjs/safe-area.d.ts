import type { MiniAppClient } from "./client.js";
/** Sum host cutout and header insets; missing data preserves CSS env() fallbacks. */
export declare function bindSafeAreaCss(client: MiniAppClient, options?: {
    prefix?: string;
}): () => void;
